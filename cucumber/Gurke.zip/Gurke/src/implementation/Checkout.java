package implementation;

public class Checkout {

	private int runningTotal = 0;

	public void add(int count, int price) {
		System.out.println("Checkout.add;  count: " + count + ", price: " + price);
		runningTotal += (count * price);
		System.out.println("Checkout.add;  total: " + runningTotal);
	}

	public int total() {
		return runningTotal;
	}

	public void clear() {
		runningTotal = 0;
	}

}