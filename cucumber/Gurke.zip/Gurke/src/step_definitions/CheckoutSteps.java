package step_definitions;

import cucumber.api.java.en.*;
import cucumber.api.PendingException;
import implementation.Checkout;
import static org.junit.Assert.*;

public class CheckoutSteps {
	int bananaPrice = 0;
	int applePrice = 0;
	Checkout checkout = new Checkout();

	@Given("^the price of a \"(.*?)\" is (\\d+)c$")
	public void thePriceOfAIsC(String name, int price) throws Throwable {
		System.out.println("name: " + name + ", price:" + price);
		if (name.contains("banana")) {
			bananaPrice = price;
		}
		if (name.contains("apple")) {
			applePrice = price;
		}

	}

	@When("^I checkout (\\d+) \"(.*?)\"$")
	public void iCheckout(int itemCount, String itemName) throws Throwable {
		System.out.println("itemCount: " + itemCount + ", itemName: " + itemName);
		// checkout = new Checkout();
		if (itemName.contains("banana")) {
			checkout.add(itemCount, bananaPrice);
		}
		if (itemName.contains("apple")) {
			checkout.add(itemCount, applePrice);
		}
		System.out.println("itemCount: " + itemCount + ", bananaPrice: " + bananaPrice);
	}

	@Then("^the total price should be (\\d+)c$")
	public void theTotalPriceShouldBeC(int total) throws Throwable {
		System.out.println("theTotalPriceShouldBeC,  total: " + total);
		System.out.println();
		System.out.println("*******************************************************");
		assertEquals(total, checkout.total());

		System.out.println();
		System.out.println();
		checkout.clear();
	}
}
