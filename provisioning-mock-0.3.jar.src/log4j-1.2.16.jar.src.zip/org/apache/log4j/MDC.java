/*     */ package org.apache.log4j;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import org.apache.log4j.helpers.Loader;
/*     */ import org.apache.log4j.helpers.ThreadLocalMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MDC
/*     */ {
/*  45 */   static final MDC mdc = new MDC();
/*     */   
/*     */   static final int HT_SIZE = 7;
/*     */   
/*     */   boolean java1;
/*     */   
/*     */   Object tlm;
/*     */   
/*     */   private MDC()
/*     */   {
/*  55 */     this.java1 = Loader.isJava1();
/*  56 */     if (!this.java1) {
/*  57 */       this.tlm = new ThreadLocalMap();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void put(String key, Object o)
/*     */   {
/*  73 */     if (mdc != null) {
/*  74 */       mdc.put0(key, o);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Object get(String key)
/*     */   {
/*  86 */     if (mdc != null) {
/*  87 */       return mdc.get0(key);
/*     */     }
/*  89 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void remove(String key)
/*     */   {
/* 100 */     if (mdc != null) {
/* 101 */       mdc.remove0(key);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Hashtable getContext()
/*     */   {
/* 111 */     if (mdc != null) {
/* 112 */       return mdc.getContext0();
/*     */     }
/* 114 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void clear()
/*     */   {
/* 123 */     if (mdc != null) {
/* 124 */       mdc.clear0();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void put0(String key, Object o)
/*     */   {
/* 131 */     if ((this.java1) || (this.tlm == null)) {
/* 132 */       return;
/*     */     }
/* 134 */     Hashtable ht = (Hashtable)((ThreadLocalMap)this.tlm).get();
/* 135 */     if (ht == null) {
/* 136 */       ht = new Hashtable(7);
/* 137 */       ((ThreadLocalMap)this.tlm).set(ht);
/*     */     }
/* 139 */     ht.put(key, o);
/*     */   }
/*     */   
/*     */ 
/*     */   private Object get0(String key)
/*     */   {
/* 145 */     if ((this.java1) || (this.tlm == null)) {
/* 146 */       return null;
/*     */     }
/* 148 */     Hashtable ht = (Hashtable)((ThreadLocalMap)this.tlm).get();
/* 149 */     if ((ht != null) && (key != null)) {
/* 150 */       return ht.get(key);
/*     */     }
/* 152 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void remove0(String key)
/*     */   {
/* 159 */     if ((!this.java1) && (this.tlm != null)) {
/* 160 */       Hashtable ht = (Hashtable)((ThreadLocalMap)this.tlm).get();
/* 161 */       if (ht != null) {
/* 162 */         ht.remove(key);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private Hashtable getContext0()
/*     */   {
/* 170 */     if ((this.java1) || (this.tlm == null)) {
/* 171 */       return null;
/*     */     }
/* 173 */     return (Hashtable)((ThreadLocalMap)this.tlm).get();
/*     */   }
/*     */   
/*     */ 
/*     */   private void clear0()
/*     */   {
/* 179 */     if ((!this.java1) && (this.tlm != null)) {
/* 180 */       Hashtable ht = (Hashtable)((ThreadLocalMap)this.tlm).get();
/* 181 */       if (ht != null) {
/* 182 */         ht.clear();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /root/testnetzrepository/provisioning-mock-0.3.jar!/log4j-1.2.16.jar!/org/apache/log4j/MDC.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */