/*     */ package org.apache.log4j.net;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.util.Vector;
/*     */ import org.apache.log4j.AppenderSkeleton;
/*     */ import org.apache.log4j.helpers.CyclicBuffer;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SocketHubAppender
/*     */   extends AppenderSkeleton
/*     */ {
/*     */   static final int DEFAULT_PORT = 4560;
/* 114 */   private int port = 4560;
/* 115 */   private Vector oosList = new Vector();
/* 116 */   private ServerMonitor serverMonitor = null;
/* 117 */   private boolean locationInfo = false;
/* 118 */   private CyclicBuffer buffer = null;
/*     */   
/*     */ 
/*     */   private String application;
/*     */   
/*     */   private boolean advertiseViaMulticastDNS;
/*     */   
/*     */   private ZeroConfSupport zeroConf;
/*     */   
/*     */   public static final String ZONE = "_log4j_obj_tcpaccept_appender.local.";
/*     */   
/*     */ 
/*     */   public SocketHubAppender() {}
/*     */   
/*     */ 
/*     */   public SocketHubAppender(int _port)
/*     */   {
/* 135 */     this.port = _port;
/* 136 */     startServer();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void activateOptions()
/*     */   {
/* 143 */     if (this.advertiseViaMulticastDNS) {
/* 144 */       this.zeroConf = new ZeroConfSupport("_log4j_obj_tcpaccept_appender.local.", this.port, getName());
/* 145 */       this.zeroConf.advertise();
/*     */     }
/* 147 */     startServer();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void close()
/*     */   {
/* 157 */     if (this.closed) {
/* 158 */       return;
/*     */     }
/* 160 */     LogLog.debug("closing SocketHubAppender " + getName());
/* 161 */     this.closed = true;
/* 162 */     if (this.advertiseViaMulticastDNS) {
/* 163 */       this.zeroConf.unadvertise();
/*     */     }
/* 165 */     cleanUp();
/*     */     
/* 167 */     LogLog.debug("SocketHubAppender " + getName() + " closed");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cleanUp()
/*     */   {
/* 176 */     LogLog.debug("stopping ServerSocket");
/* 177 */     this.serverMonitor.stopMonitor();
/* 178 */     this.serverMonitor = null;
/*     */     
/*     */ 
/* 181 */     LogLog.debug("closing client connections");
/* 182 */     while (this.oosList.size() != 0) {
/* 183 */       ObjectOutputStream oos = (ObjectOutputStream)this.oosList.elementAt(0);
/* 184 */       if (oos != null) {
/*     */         try {
/* 186 */           oos.close();
/*     */         } catch (InterruptedIOException e) {
/* 188 */           Thread.currentThread().interrupt();
/* 189 */           LogLog.error("could not close oos.", e);
/*     */         } catch (IOException e) {
/* 191 */           LogLog.error("could not close oos.", e);
/*     */         }
/*     */         
/* 194 */         this.oosList.removeElementAt(0);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void append(LoggingEvent event)
/*     */   {
/* 203 */     if (event != null)
/*     */     {
/* 205 */       if (this.locationInfo) {
/* 206 */         event.getLocationInformation();
/*     */       }
/* 208 */       if (this.application != null) {
/* 209 */         event.setProperty("application", this.application);
/*     */       }
/* 211 */       event.getNDC();
/* 212 */       event.getThreadName();
/* 213 */       event.getMDCCopy();
/* 214 */       event.getRenderedMessage();
/* 215 */       event.getThrowableStrRep();
/*     */       
/* 217 */       if (this.buffer != null) {
/* 218 */         this.buffer.add(event);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 223 */     if ((event == null) || (this.oosList.size() == 0)) {
/* 224 */       return;
/*     */     }
/*     */     
/*     */ 
/* 228 */     for (int streamCount = 0; streamCount < this.oosList.size(); streamCount++)
/*     */     {
/* 230 */       ObjectOutputStream oos = null;
/*     */       try {
/* 232 */         oos = (ObjectOutputStream)this.oosList.elementAt(streamCount);
/*     */       }
/*     */       catch (ArrayIndexOutOfBoundsException e) {}
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 241 */       if (oos == null) {
/*     */         break;
/*     */       }
/*     */       try {
/* 245 */         oos.writeObject(event);
/* 246 */         oos.flush();
/*     */         
/*     */ 
/*     */ 
/* 250 */         oos.reset();
/*     */       }
/*     */       catch (IOException e) {
/* 253 */         if ((e instanceof InterruptedIOException)) {
/* 254 */           Thread.currentThread().interrupt();
/*     */         }
/*     */         
/* 257 */         this.oosList.removeElementAt(streamCount);
/* 258 */         LogLog.debug("dropped connection");
/*     */         
/*     */ 
/* 261 */         streamCount--;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean requiresLayout()
/*     */   {
/* 271 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPort(int _port)
/*     */   {
/* 279 */     this.port = _port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setApplication(String lapp)
/*     */   {
/* 288 */     this.application = lapp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getApplication()
/*     */   {
/* 296 */     return this.application;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 303 */     return this.port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBufferSize(int _bufferSize)
/*     */   {
/* 312 */     this.buffer = new CyclicBuffer(_bufferSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBufferSize()
/*     */   {
/* 320 */     if (this.buffer == null) {
/* 321 */       return 0;
/*     */     }
/* 323 */     return this.buffer.getMaxSize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocationInfo(boolean _locationInfo)
/*     */   {
/* 333 */     this.locationInfo = _locationInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean getLocationInfo()
/*     */   {
/* 340 */     return this.locationInfo;
/*     */   }
/*     */   
/*     */   public void setAdvertiseViaMulticastDNS(boolean advertiseViaMulticastDNS) {
/* 344 */     this.advertiseViaMulticastDNS = advertiseViaMulticastDNS;
/*     */   }
/*     */   
/*     */   public boolean isAdvertiseViaMulticastDNS() {
/* 348 */     return this.advertiseViaMulticastDNS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void startServer()
/*     */   {
/* 355 */     this.serverMonitor = new ServerMonitor(this.port, this.oosList);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ServerSocket createServerSocket(int socketPort)
/*     */     throws IOException
/*     */   {
/* 365 */     return new ServerSocket(socketPort);
/*     */   }
/*     */   
/*     */ 
/*     */   private class ServerMonitor
/*     */     implements Runnable
/*     */   {
/*     */     private int port;
/*     */     
/*     */     private Vector oosList;
/*     */     
/*     */     private boolean keepRunning;
/*     */     
/*     */     private Thread monitorThread;
/*     */     
/*     */ 
/*     */     public ServerMonitor(int _port, Vector _oosList)
/*     */     {
/* 383 */       this.port = _port;
/* 384 */       this.oosList = _oosList;
/* 385 */       this.keepRunning = true;
/* 386 */       this.monitorThread = new Thread(this);
/* 387 */       this.monitorThread.setDaemon(true);
/* 388 */       this.monitorThread.setName("SocketHubAppender-Monitor-" + this.port);
/* 389 */       this.monitorThread.start();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public synchronized void stopMonitor()
/*     */     {
/* 398 */       if (this.keepRunning) {
/* 399 */         LogLog.debug("server monitor thread shutting down");
/* 400 */         this.keepRunning = false;
/*     */         try {
/* 402 */           this.monitorThread.join();
/*     */         }
/*     */         catch (InterruptedException e) {
/* 405 */           Thread.currentThread().interrupt();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 410 */         this.monitorThread = null;
/* 411 */         LogLog.debug("server monitor thread shut down");
/*     */       }
/*     */     }
/*     */     
/*     */     private void sendCachedEvents(ObjectOutputStream stream) throws IOException
/*     */     {
/* 417 */       if (SocketHubAppender.this.buffer != null) {
/* 418 */         for (int i = 0; i < SocketHubAppender.this.buffer.length(); i++) {
/* 419 */           stream.writeObject(SocketHubAppender.this.buffer.get(i));
/*     */         }
/* 421 */         stream.flush();
/* 422 */         stream.reset();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void run()
/*     */     {
/* 431 */       ServerSocket serverSocket = null;
/*     */       try {
/* 433 */         serverSocket = SocketHubAppender.this.createServerSocket(this.port);
/* 434 */         serverSocket.setSoTimeout(1000);
/*     */       }
/*     */       catch (Exception e) {
/* 437 */         if (((e instanceof InterruptedIOException)) || ((e instanceof InterruptedException))) {
/* 438 */           Thread.currentThread().interrupt();
/*     */         }
/* 440 */         LogLog.error("exception setting timeout, shutting down server socket.", e);
/* 441 */         this.keepRunning = false;
/* 442 */         return;
/*     */       }
/*     */       try
/*     */       {
/*     */         try {
/* 447 */           serverSocket.setSoTimeout(1000);
/*     */         }
/*     */         catch (SocketException e) {
/* 450 */           LogLog.error("exception setting timeout, shutting down server socket.", e); return;
/*     */         }
/*     */         
/*     */ 
/* 454 */         while (this.keepRunning) {
/* 455 */           Socket socket = null;
/*     */           try {
/* 457 */             socket = serverSocket.accept();
/*     */ 
/*     */           }
/*     */           catch (InterruptedIOException e) {}catch (SocketException e)
/*     */           {
/*     */ 
/* 463 */             LogLog.error("exception accepting socket, shutting down server socket.", e);
/* 464 */             this.keepRunning = false;
/*     */           }
/*     */           catch (IOException e) {
/* 467 */             LogLog.error("exception accepting socket.", e);
/*     */           }
/*     */           
/*     */ 
/* 471 */           if (socket != null) {
/*     */             try {
/* 473 */               InetAddress remoteAddress = socket.getInetAddress();
/* 474 */               LogLog.debug("accepting connection from " + remoteAddress.getHostName() + " (" + remoteAddress.getHostAddress() + ")");
/*     */               
/*     */ 
/*     */ 
/* 478 */               ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
/* 479 */               if ((SocketHubAppender.this.buffer != null) && (SocketHubAppender.this.buffer.length() > 0)) {
/* 480 */                 sendCachedEvents(oos);
/*     */               }
/*     */               
/*     */ 
/* 484 */               this.oosList.addElement(oos);
/*     */             } catch (IOException e) {
/* 486 */               if ((e instanceof InterruptedIOException)) {
/* 487 */                 Thread.currentThread().interrupt();
/*     */               }
/* 489 */               LogLog.error("exception creating output stream on socket.", e);
/*     */             }
/*     */           }
/*     */         }
/*     */         return;
/*     */       }
/*     */       finally {
/*     */         try {
/* 497 */           serverSocket.close();
/*     */         } catch (InterruptedIOException e) {
/* 499 */           Thread.currentThread().interrupt();
/*     */         }
/*     */         catch (IOException e) {}
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /root/testnetzrepository/provisioning-mock-0.3.jar!/log4j-1.2.16.jar!/org/apache/log4j/net/SocketHubAppender.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */