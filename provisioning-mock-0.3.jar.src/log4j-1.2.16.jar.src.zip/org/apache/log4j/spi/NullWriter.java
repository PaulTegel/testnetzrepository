package org.apache.log4j.spi;

import java.io.Writer;

/**
 * @deprecated
 */
class NullWriter
  extends Writer
{
  public void close() {}
  
  public void flush() {}
  
  public void write(char[] cbuf, int off, int len) {}
}


/* Location:              /root/testnetzrepository/provisioning-mock-0.3.jar!/log4j-1.2.16.jar!/org/apache/log4j/spi/NullWriter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */