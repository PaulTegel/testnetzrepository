/*    */ package org.apache.log4j.lf5;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogLevelFormatException
/*    */   extends Exception
/*    */ {
/*    */   public LogLevelFormatException(String message)
/*    */   {
/* 48 */     super(message);
/*    */   }
/*    */ }


/* Location:              /root/testnetzrepository/provisioning-mock-0.4.jar!/log4j-1.2.16.jar!/org/apache/log4j/lf5/LogLevelFormatException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */