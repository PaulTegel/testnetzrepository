package org.apache.log4j.lf5.viewer.categoryexplorer;

import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;

public class TreeModelAdapter
  implements TreeModelListener
{
  public void treeNodesChanged(TreeModelEvent e) {}
  
  public void treeNodesInserted(TreeModelEvent e) {}
  
  public void treeNodesRemoved(TreeModelEvent e) {}
  
  public void treeStructureChanged(TreeModelEvent e) {}
}


/* Location:              /root/testnetzrepository/provisioning-mock-0.4.jar!/log4j-1.2.16.jar!/org/apache/log4j/lf5/viewer/categoryexplorer/TreeModelAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */