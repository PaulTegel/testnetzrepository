/*    */ package org.apache.log4j.pattern;
/*    */ 
/*    */ import org.apache.log4j.spi.LocationInfo;
/*    */ import org.apache.log4j.spi.LoggingEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MethodLocationPatternConverter
/*    */   extends LoggingEventPatternConverter
/*    */ {
/* 34 */   private static final MethodLocationPatternConverter INSTANCE = new MethodLocationPatternConverter();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private MethodLocationPatternConverter()
/*    */   {
/* 41 */     super("Method", "method");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static MethodLocationPatternConverter newInstance(String[] options)
/*    */   {
/* 51 */     return INSTANCE;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void format(LoggingEvent event, StringBuffer toAppendTo)
/*    */   {
/* 58 */     LocationInfo locationInfo = event.getLocationInformation();
/*    */     
/* 60 */     if (locationInfo != null) {
/* 61 */       toAppendTo.append(locationInfo.getMethodName());
/*    */     }
/*    */   }
/*    */ }


/* Location:              /root/testnetzrepository/provisioning-mock-0.4.jar!/log4j-1.2.16.jar!/org/apache/log4j/pattern/MethodLocationPatternConverter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */