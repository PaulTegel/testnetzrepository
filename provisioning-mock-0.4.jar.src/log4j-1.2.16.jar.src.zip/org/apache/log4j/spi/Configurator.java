package org.apache.log4j.spi;

import java.net.URL;

public abstract interface Configurator
{
  public static final String INHERITED = "inherited";
  public static final String NULL = "null";
  
  public abstract void doConfigure(URL paramURL, LoggerRepository paramLoggerRepository);
}


/* Location:              /root/testnetzrepository/provisioning-mock-0.4.jar!/log4j-1.2.16.jar!/org/apache/log4j/spi/Configurator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */