#!/bin/bash

source ~/testnetz-dns/utils.sh
source ~/testnetz-dns/utils_docker.sh

function main()
{
	
	# Docker env-Variablen einlesen
	. ~/testnetz/.env

	stop_docker_env
	reset_docker_env
	echo "NOTE: Script $SCRIPT_FILENAME wurde ausgefuehrt."
}

main
exit 0
