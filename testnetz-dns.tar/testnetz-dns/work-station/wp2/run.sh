#!/bin/sh
set -e

#echo "eth0:0 10.33.128.210/24 up ..."

#ifconfig eth0:0 10.33.128.210/24 up
