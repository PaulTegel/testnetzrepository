import org.apache.commons.lang.StringEscapeUtils;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Hyperlink;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class Main extends Application {

	String begin = "&lt;html&gt;&lt;body&gt;";
	String end = "&lt;/body&gt;&lt;/html&gt;";
	String content;

	@Override
	public void start(Stage stage) {
		stage.setTitle("HTML");
		stage.setWidth(500);
		stage.setHeight(500);
		Scene scene = new Scene(new Group());
		VBox root = new VBox();
		final WebView browser = new WebView();
		final WebEngine webEngine = browser.getEngine();
		Hyperlink hpl = new Hyperlink("java2s.com");
		hpl.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent e) {
				webEngine.load("http://localhost:8080/details?id=9503");

				// webEngine.loadContent(content);

				String html = (String) webEngine.executeScript("document.documentElement.outerHTML");

				System.out.println(html);
//				begin = "<html><body>";
//				end = "</body></html>";

				try {
					System.out.println("begin: " + html.indexOf(begin));
				}catch (Exception e1) {
					// TODO: handle exception
				}
				
				try {
					System.out.println("end: " + html.indexOf(end));
				}catch (Exception e1) {
					// TODO: handle exception
				}
				
				
				
				try {
					
//					System.out.println(html.indexOf(begin));
//					System.out.println(html.indexOf(end));
					
					String html_2 = html.substring(html.indexOf(begin)+begin.length(), html.indexOf(end));
					
//					System.out.println(webEngine.getDocument().getElementsByTagName("p").toString());
					
					System.out.println(html_2);
					content = html_2;
					
				} catch (Exception ex) {
					System.out.println(ex.getMessage());
				}

			}
		});
		
		
		
		String ind = "<html><body> Das Fachmodul VSDM MUSS bei Aufruf der Operation GetUpdateFlags den Request-Header mit den Werten in Tabelle Tab_SST_FD_02 bilden. Dieser Testfall pr&uuml;ft: 1. Aufruf von ReadVSD mit PerformOnlineCheck = true 2. Abfrage des Update Flag Service (GetUpdateFlags) 3. ServiceLocalization-Header enth&auml;lt korrekte ServiceType und ProviderID. 4. Korrekte ReadVSD-Response des Konnektors </body></html>";
		
		
		Hyperlink hp2 = new Hyperlink("go");
		hp2.setOnAction(new EventHandler<ActionEvent>() {
			

			@Override
			public void handle(ActionEvent e) {
//				webEngine.loadContent("<html><body>" + content + "</body></html>");
				
//				String s1 = ind.replace("1.", "</br>1.").replace("2.", "</br>2.").replace("3.", "</br>3.").replace("4.", "</br>4.").replace("5.", "</br>5.").replace("6.", "</br>6.").replace("7.", "</br>7.").replace("8.", "</br>8.").replace("9.", "</br>9.").replace("10.", "</br>10.").replace("11.", "</br>11.").replace("12.", "</br>12.").replace("13.", "</br>13.").replace("14.", "</br>14.").replace("15.", "</br>15.").replace("16.", "</br>16.");
//				webEngine.loadContent(s1);


				String s1 = content.replace("1.", "</br>1.").replace("2.", "</br>2.").replace("3.", "</br>3.").replace("4.", "</br>4.").replace("5.", "</br>5.").replace("6.", "</br>6.").replace("7.", "</br>7.").replace("8.", "</br>8.").replace("9.", "</br>9.").replace("10.", "</br>10.").replace("11.", "</br>11.").replace("12.", "</br>12.").replace("13.", "</br>13.").replace("14.", "</br>14.").replace("15.", "</br>15.").replace("16.", "</br>16.");
				
				String decodedXML= StringEscapeUtils.unescapeHtml(s1);

				webEngine.loadContent("<html><body>" + decodedXML + "</body></html>", "text/html");

			}
		});

		root.getChildren().addAll(hpl, hp2, browser);
//		root.getChildren().addAll(hp2, browser);
		scene.setRoot(root);

		stage.setScene(scene);
		stage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}
