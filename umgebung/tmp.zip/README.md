# Konnektor Testnetz

## Inhalt

### Allgemein
- README.md
  Diese Datei

- base-image
  Basis-Image fuer alle anderen Docker Images

- base-image-konzentrator
  Basis-Image fuer VPN Konzentratoren mit angepasstem Strongswan, welcher die
  Chain of Trust Pruefung manipuliert.

- docker-compose.yml
  docker-compose Steuerdatei

- docker-compose-FHI.yml
  docker-compose Steuerdatei mit FHI-spezifischen Änderungen

- docker-compose-FHI-2lan-interfaces.yml
  docker-compose Steuerdatei mit FHI-spezifischen Änderungen + 2 Netzwerkkarten

- konnektor
  Dateien zur Einrichtung eines Konnektors fuer die Benutzung im Testnetz.
  
### Docker Images entsprechend Netzplan
- crl-ti
- dns-public
- dns-ti
- dns-sis
- intermediaer-ti
- ksr-ti
- lansim
- ntp-ti
- ocsp-ti
- register-ti
- remoteserver
- router
- sis-konzentrator
- ti-konzentrator
- trust-anchor
- vsdm-ti
- vsdm-ti-offen-fd
- work-station


# Basis-Image
Wir verwenden ein Basis-Image für alle Container.
Zur Benutzung bitte Hinweise in
https://ftp1.openlimit.com/poc/ansible/blob/master/roles/base-image/README.md -> Link funktioniert nicht! ftp Domain OpenLimit existiert nicht mehr
beachten.
