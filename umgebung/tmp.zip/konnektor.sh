#!/bin/bash

set -e
set -x

export KONNEKTOR_SCR_DEVICEBUS=$(konnektor/find_first_smartcardreader.sh)

docker-compose -f docker-compose.yml -f konnektor/compose.yml $@
