package dns;

import java.net.UnknownHostException;

import org.xbill.DNS.Lookup;
import org.xbill.DNS.Record;
import org.xbill.DNS.Resolver;
import org.xbill.DNS.SimpleResolver;
import org.xbill.DNS.TextParseException;
import org.xbill.DNS.Type;

public class DnsExperimente {

	private static final String IP = "172.17.0.2";
//	private static final String IP = "172.17.60.60";
	private static final String DOMAIN = "localhost";
	
	
	public static void main(String[] args) throws TextParseException, UnknownHostException {
		
		DnsExperimente dnsexperiment = new DnsExperimente();
		
		Lookup lookup = dnsexperiment.getLookup(Type.ANY);
		Record[] records = lookup.run();
		
		for(Record record : records){
			System.out.println(record.toString());
		}	
		
	}

	
	private Lookup getLookup(int type) throws TextParseException, UnknownHostException {
		Lookup lookup = new Lookup(DOMAIN, type);
		Resolver resolver = new SimpleResolver(IP);
		lookup.setResolver(resolver);
		lookup.setCache(null); // no cache
		return lookup;
	}
}
