package dns;

import java.net.UnknownHostException;

import org.junit.Assert;
import org.junit.Test;
import org.xbill.DNS.ARecord;
import org.xbill.DNS.Lookup;
import org.xbill.DNS.MXRecord;
import org.xbill.DNS.NSRecord;
import org.xbill.DNS.Record;
import org.xbill.DNS.Resolver;
import org.xbill.DNS.SimpleResolver;
import org.xbill.DNS.TextParseException;
import org.xbill.DNS.Type;

public class DnsLookupTest {

	private static final String IP = "172.17.0.2";
	private static final String DOMAIN = "localhost";

	@Test
	public void testMX() throws Exception {
		Lookup lookup = getLookup(Type.MX);
		Record[] records = lookup.run();
		
		for(Record record : records){
			System.out.println(record.toString());
		}
		

		Assert.assertEquals(Lookup.SUCCESSFUL, lookup.getResult());
		Assert.assertEquals(1, records.length);
		Record mxRecord = records[0];
		Assert.assertTrue(mxRecord instanceof MXRecord);
		Assert.assertEquals("mail.localhost", ((MXRecord) mxRecord).getTarget().toString());
	}

	@Test
	public void testNS() throws Exception {
		Lookup lookup = getLookup(Type.NS);
		Record[] records = lookup.run();

		Assert.assertEquals(Lookup.SUCCESSFUL, lookup.getResult());
		Assert.assertEquals(2, records.length);
		Assert.assertTrue(records[0] instanceof NSRecord);
		Assert.assertTrue(records[1] instanceof NSRecord);
	}

	@Test
	public void testA() throws Exception {
		Lookup lookup = getLookup(Type.A);
		Record[] records = lookup.run();

		Assert.assertEquals(Lookup.SUCCESSFUL, lookup.getResult());
		Assert.assertEquals(1, records.length);
		Record aRecord = records[0];
		Assert.assertTrue(aRecord instanceof ARecord);
		Assert.assertEquals(DOMAIN + ".", ((ARecord) aRecord).getName().toString());
		Assert.assertEquals(IP, ((ARecord) aRecord).getAddress().getHostAddress());
	}

	private Lookup getLookup(int type) throws TextParseException, UnknownHostException {
		Lookup lookup = new Lookup(DOMAIN, type);
		Resolver resolver = new SimpleResolver(IP);
		lookup.setResolver(resolver);
		lookup.setCache(null); // no cache
		return lookup;
	}
}